#' plotflow: Tools to speed up workflow associated with plotting
#'
#' Plotting functions designed to increase efficiency around plotting.
#' 
#' @docType package
#' @name plotflow
#' @aliases plotflow package-plotflow
NULL


